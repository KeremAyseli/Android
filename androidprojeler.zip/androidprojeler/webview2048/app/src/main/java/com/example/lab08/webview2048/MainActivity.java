package com.example.lab08.webview2048;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {
  WebView wbview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        wbview = findViewById(R.id.webview);
        wbview.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        wbview.loadUrl("file:///android_asset/index.html");
    }
}
