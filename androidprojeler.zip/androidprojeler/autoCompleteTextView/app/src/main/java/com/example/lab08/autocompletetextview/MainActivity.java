package com.example.lab08.autocompletetextview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;

public class MainActivity extends AppCompatActivity {
   AutoCompleteTextView auto;
   MultiAutoCompleteTextView multiauto;
   String [] hayvanlar = {"kedi","kelaynak","kefal","balık","bal porsuğu"};
    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        auto = findViewById(R.id.autoCompleteTextView);
        multiauto = findViewById(R.id.multiAutoCompleteTextView);

        adapter = new ArrayAdapter<>(
                getApplication(),
                android.R.layout.simple_list_item_1,
                hayvanlar
        );
        auto.setThreshold(2);
        auto.setAdapter(adapter);

        multiauto.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
        multiauto.setAdapter(adapter);
        auto.setAdapter(adapter);
    }
}
