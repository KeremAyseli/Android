package com.example.lab08.sesdosyalarilecalsma;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {
   MediaPlayer mp ;
   ImageButton ımg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
            ımg = findViewById(R.id.imageButton);
            mp = MediaPlayer.create(this,R.raw.ses_mp3);
            ımg.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(!mp.isPlaying())
                    {
                        mp.start();
                    }
                    else {
                        mp.pause();
                    }
                }
            });
    }

    @Override
    protected void onPause() {
        super.onPause();
        mp.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mp.start();
    }
}
