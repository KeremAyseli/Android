package com.example.lab08.programatik_nesne_olusturma;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
   LinearLayout lyout;
   EditText edt ;
   Button btn;
   public void nesneolustur(int sayıadedi)
   {for(int i =0;i<sayıadedi;i++) {
       Button btn1 = new Button(getApplicationContext());
       btn1.setText("Button");

       lyout.addView(btn1);
   }
   }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lyout = findViewById(R.id.linearLayout);
        edt = findViewById(R.id.edittext2);
        btn = findViewById(R.id.btn2);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nesneolustur(Integer.parseInt(edt.getText().toString()));
            }
        });

    }
}
