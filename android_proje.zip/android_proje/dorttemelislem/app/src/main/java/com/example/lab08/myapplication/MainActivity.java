package com.example.lab08.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btntopla,btncıkar,btncarp,btnbol;
    EditText deger1,deger2;
    TextView sonuc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btntopla=findViewById(R.id.btntopla);
        btncıkar = findViewById(R.id.btncıkar);
        btncarp = findViewById(R.id.btncarp);
        btnbol = findViewById(R.id.btnbol);
        deger1 = findViewById(R.id.deger1);
        deger2=findViewById(R.id.deger2);
        sonuc = findViewById(R.id.sonuc);
        btntopla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              int gelen =Integer.parseInt(deger1.getText().toString());
         int gelen1 =Integer.parseInt(deger2.getText().toString());
         int sonuc1 = gelen+gelen1;
                sonuc.setText(""+sonuc1);

            }
        });
        btncıkar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int gelen =Integer.parseInt(deger1.getText().toString());
                int gelen1 =Integer.parseInt(deger2.getText().toString());
               int sonuc1 =gelen-gelen1;
                sonuc.setText(""+sonuc1);
            }
        });
        btncarp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int gelen =Integer.parseInt(deger1.getText().toString());
                int gelen1 =Integer.parseInt(deger2.getText().toString());
               int sonuc1 =gelen*gelen1;
                sonuc.setText(""+sonuc1);
            }
        });
        btnbol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int gelen =Integer.parseInt(deger1.getText().toString());
                int gelen1 =Integer.parseInt(deger2.getText().toString());
                int sonuc1 = gelen/gelen1;
                sonuc.setText(""+sonuc1);
            }
        });

    }
}
