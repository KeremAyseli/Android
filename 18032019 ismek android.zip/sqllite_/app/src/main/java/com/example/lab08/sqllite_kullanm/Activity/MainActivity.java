package com.example.lab08.sqllite_kullanm.Activity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.lab08.sqllite_kullanm.Adapter.Rehber_adapter;
import com.example.lab08.sqllite_kullanm.Model.Rehber;
import com.example.lab08.sqllite_kullanm.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
   EditText editText;
   ListView listView;
   Button button;
   Rehber_adapter rehber_adapter;
   ArrayList<Rehber>kisiler = new ArrayList<>();

   private void kisiGuncellemeDialog(int id,String ad,String soyad, String email,String not,String telefon,String telefonTur,String webSite){

       Dialog dialog = new Dialog(MainActivity.this);
       dialog.setContentView(R.layout.rehber_kisi_guncelle);
       EditText etAd,etSoyad,etMail,etNot,etTelefon,etTelefonTur,etWeb;
       Button btn;
       etAd =dialog.findViewById(R.id.etAd);
       etSoyad =dialog. findViewById(R.id.etsoyad);
       etMail =dialog. findViewById(R.id.etMailAdresi);
       etNot = dialog.findViewById(R.id.etNot);
       etTelefon =dialog. findViewById(R.id.etTelefonNo);
       etTelefonTur =dialog. findViewById(R.id.etTelefonTur);
       etWeb =dialog. findViewById(R.id.etWebsite);
       btn =dialog.findViewById(R.id.btnIslem);
       etAd.setText(ad);
       etSoyad.setText(soyad);
       etMail.setText(email);
       etTelefon.setText(""+telefon);
       etTelefonTur.setText(telefonTur);
       etNot.setText(not);
       etWeb.setText(webSite);
       btn.setText("Güncelle");
       btn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

           }
       });
       dialog.show();
   }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText=findViewById(R.id.etArama);
        listView =findViewById(R.id.listViewKisiler);
        button = findViewById(R.id.btnKisiEkle);

        kisiler.add(new Rehber(
                1,
                "şerif",
                "gungör",
                "05369997788",
                "contact@serifgungor.com",
                "cep",
                "https://cdn3.iconfinder.com/data/icons/gray-toolbar-2/512/profile_user_account_human-512.png",
                "",
                ""
        ));
        kisiler.add(new Rehber(
                1,
                "denem",
                "soyisim",
                "05369996688",
                "denemesoyisim@outlook.com",
                "cep",
                "https://previews.123rf.com/images/eriksvoboda/eriksvoboda1411/eriksvoboda141100009/33211652-unknown-person-silhouette-whith-blue-tie-profile-picture-silhouette-profile.jpg",
                "",
                ""
        ));
        kisiler.add(new Rehber(
                1,
                "isim",
                "soyisim",
                "05369997799",
                "contact@serifgungor.com",
                "cep",
                "https://cdn0.iconfinder.com/data/icons/superuser-web-kit/512/686909-user_people_man_human_head_person-512.png",
                "",
                ""
        ));
        kisiler.add(new Rehber(
                1,
                "kerem",
                "ayseli",
                "05369954684",
                "keremayseli@outlook.com",
                "cep",
                "https://www.shareicon.net/data/256x256/2015/09/24/106687_user_512x512.png",
                "",
                ""
        ));

        rehber_adapter=new Rehber_adapter(kisiler,getApplicationContext());
        listView.setAdapter(rehber_adapter);
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
                adb.setTitle("işlem seçiniz");
                adb.setMessage("Silmek ya da güncellemek üzere bir butona tıklayanız");
                adb.setPositiveButton("Güncelle", new DialogInterface.OnClickListener() {
                    @Override //int id,String ad,String soyad, String email,String not,String telefon,String telefonTur,String webSite
                    public void onClick(DialogInterface dialog, int which) {
                        kisiGuncellemeDialog(kisiler.get(position).getId(),kisiler.get(position).getAd(),kisiler.get(position).getSoyad(),kisiler.get(position).getMailAdresi(),kisiler.get(position).getNot(),kisiler.get(position).getTelefonNo(),kisiler.get(position).getTelefonTuru(),kisiler.get(position).getWebSite());
                    }
                });
                adb.setNegativeButton("Sil", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                adb.setNeutralButton("Vazgeç", null);
                adb.create();
                adb.show();
                return false;
            }
        });

    }
}
