package com.example.lab08.bloglarlistelem_adapter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.example.lab08.bloglarlistelem_adapter.model.Blog;

public class BlogDetayActivity extends AppCompatActivity {

    WebView vbsite ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blog_detay);
        vbsite=findViewById(R.id.wbsite);
        Blog blog = (Blog)getIntent().getSerializableExtra("blog");
        setTitle(blog.getBaslik());

        vbsite.loadUrl(blog.getWrbUrl());
        vbsite.setWebViewClient(new WebViewClient());
    }
}
