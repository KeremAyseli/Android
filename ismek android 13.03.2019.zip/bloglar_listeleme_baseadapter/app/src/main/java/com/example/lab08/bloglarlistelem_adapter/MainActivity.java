package com.example.lab08.bloglarlistelem_adapter;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;

import com.example.lab08.bloglarlistelem_adapter.Adapter.Blog_adapter;
import com.example.lab08.bloglarlistelem_adapter.model.Blog;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText etYazi;
    ListView litView;
    Blog_adapter adapter;
    ArrayList<Blog> bloglar = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etYazi = findViewById(R.id.etArama);
        litView =findViewById(R.id.listViewBloglar);
        adapter = new Blog_adapter(getApplicationContext(),bloglar);
        litView.setAdapter(adapter);
        etYazi.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                final String sorgu = s.toString().toLowerCase().trim();
                final ArrayList<Blog> geciciListe = new ArrayList<>();

                for(int k=0; k<bloglar.size(); k++){
                    if(bloglar.get(k).getBaslik().toLowerCase().contains(sorgu)){
                        geciciListe.add(bloglar.get(k));
                    }
                }

                Blog_adapter adapter = new Blog_adapter(getApplicationContext(),geciciListe);
                litView.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
            bloglar.add(new Blog(
                    1,
                    "-php-thumbnail-resim-olusturma",
                    "Blog içerik yazısı",
                    "Yazar",
                    "13.03.2019 16:16",
                    "13.03.2019 16:20",
                    "https://serifgungor.com/content/uploads/images/0219/php_thumbnail_image_ornegi.jpg",
                    10,
                    "https://serifgungor.com"
            ));
        bloglar.add(new Blog(
                1,
                "-android-url-bitmap-kullanimi",
                "Blog içerik yazısı",
                "Yazar",
                "13.03.2019 16:16",
                "13.03.2019 16:20",
                "https://serifgungor.com/content/uploads/images/0119/android-http-url-connection-bitmap-kullanimi-2.jpg",
                10,
                "https://serifgungor.com"
        ));
        bloglar.add(new Blog(
                1,
                "-android-sensormanager-kullanimi",
                "Blog içerik yazısı",
                "Yazar",
                "13.03.2019 16:16",
                "13.03.2019 16:20",
                "https://serifgungor.com/content/uploads/images/0119/android-sensormanager-kullanimi.jpg",
                10,
                "https://serifgungor.com"
        ));
        bloglar.add(new Blog(
                1,
                "Merhaba Blog",
                "-android-listactivity-kullanimi",
                "Yazar",
                "13.03.2019 16:16",
                "13.03.2019 16:20",
                "https://serifgungor.com/content/uploads/images/0119/android-listactivity-kullanimi.jpg",
                10,
                "https://serifgungor.com"
        )); bloglar.add(new Blog(
                1,
                "Merhaba Blog",
                "android-alarm-manager-kullanimi",
                "Yazar",
                "13.03.2019 16:16",
                "13.03.2019 16:20",
                "https://serifgungor.com/content/uploads/images/0119/android-alarm-manager-kullanimi.jpg",
                10,
                "https://serifgungor.com"
        ));


litView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {



        Intent intent = new Intent(getApplicationContext(),BlogDetayActivity.class);
          intent.putExtra("blog", bloglar.get(position));
        startActivity(intent);
    }
});
    }
}
