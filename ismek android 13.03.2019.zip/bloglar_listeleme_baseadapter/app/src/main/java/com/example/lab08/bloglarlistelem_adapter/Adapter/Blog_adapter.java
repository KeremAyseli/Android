package com.example.lab08.bloglarlistelem_adapter.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.lab08.bloglarlistelem_adapter.R;
import com.example.lab08.bloglarlistelem_adapter.model.Blog;

import java.util.ArrayList;

public class Blog_adapter extends BaseAdapter {
    Context context;
    ArrayList<Blog> blog;
    LayoutInflater layoutInflater;

    public Blog_adapter() {
    }

    public Blog_adapter(Context context, ArrayList<Blog> blog) {
        this.context = context;
        this.blog = blog;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return blog.size();
    }

    @Override
    public Object getItem(int position) {
        return blog.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v =layoutInflater.inflate(R.layout.blog_satr,null);
        ImageView ivResim = v.findViewById(R.id.ivresim);
        TextView tvBaslik = v.findViewById(R.id.tvBaslik);
        TextView tvEklenmetarihi = v.findViewById(R.id.textView5);
        TextView tvOkunmasayısı = v.findViewById(R.id.textView6);
        TextView tvYazar = v.findViewById(R.id.textView7);
        tvBaslik.setText(blog.get(position).getBaslik());
        tvEklenmetarihi.setText(""+blog.get(position).getEklemeTarihi());
        tvYazar.setText(blog.get(position).getYazar());
        tvOkunmasayısı.setText(""+blog.get(position).getOkunmasayisi());
        Glide.with(context).load(blog.get(position).getResimUrl()).into(ivResim);
        return v;
    }
}
