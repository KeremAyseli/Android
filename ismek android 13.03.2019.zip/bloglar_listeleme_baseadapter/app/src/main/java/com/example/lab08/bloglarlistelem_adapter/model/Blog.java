package com.example.lab08.bloglarlistelem_adapter.model;

import java.io.Serializable;

public class Blog implements Serializable {

    private int id;
    private String baslik;
    private String icerikYazisi;
    private String yazar;
    private String eklemeTarihi;
    private String sonGuncellemeTarihi;
    private String resimUrl;
    private int okunmasayisi;
    private  String wrbUrl;

    public Blog(int id, String baslik, String icerikYazisi, String yazar, String eklemeTarihi, String sonGuncellemeTarihi, String resimUrl, int okunmasayisi,String webUrl) {
        this.id = id;
        this.baslik = baslik;
        this.icerikYazisi = icerikYazisi;
        this.yazar = yazar;
        this.eklemeTarihi = eklemeTarihi;
        this.sonGuncellemeTarihi = sonGuncellemeTarihi;
        this.resimUrl = resimUrl;
        this.okunmasayisi = okunmasayisi;
        this.wrbUrl=webUrl;
    }

    public String getWrbUrl() {
        return wrbUrl;
    }

    public void setWrbUrl(String wrbUrl) {
        this.wrbUrl = wrbUrl;
    }

    public Blog() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }

    public String getIcerikYazisi() {
        return icerikYazisi;
    }

    public void setIcerikYazisi(String icerikYazisi) {
        this.icerikYazisi = icerikYazisi;
    }

    public String getYazar() {
        return yazar;
    }

    public void setYazar(String yazar) {
        this.yazar = yazar;
    }

    public String getEklemeTarihi() {
        return eklemeTarihi;
    }

    public void setEklemeTarihi(String eklemeTarihi) {
        this.eklemeTarihi = eklemeTarihi;
    }

    public String getSonGuncellemeTarihi() {
        return sonGuncellemeTarihi;
    }

    public void setSonGuncellemeTarihi(String sonGuncellemeTarihi) {
        this.sonGuncellemeTarihi = sonGuncellemeTarihi;
    }

    public String getResimUrl() {
        return resimUrl;
    }

    public void setResimUrl(String resimUrl) {
        this.resimUrl = resimUrl;
    }

    public int getOkunmasayisi() {
        return okunmasayisi;
    }

    public void setOkunmasayisi(int okunmasayisi) {
        this.okunmasayisi = okunmasayisi;
    }
}
