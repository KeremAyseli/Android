package com.example.lab08.kitapbaseadapter.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.lab08.kitapbaseadapter.Adapter.AdapterKategori;
import com.example.lab08.kitapbaseadapter.Model.Kategori;
import com.example.lab08.kitapbaseadapter.Model.Kitap;
import com.example.lab08.kitapbaseadapter.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    GridView gridView;
    ArrayList<Kategori> kategoriler = new ArrayList<>();
    AdapterKategori adapterKategori;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = findViewById(R.id.gridView);

        kategoriler.add(new Kategori(1,"Bilgisayar","https://cdn.vatanbilgisayar.com/UPLOAD/PRODUCT/HOMETECH/thumb/v2-90171_medium.jpg"));
        kategoriler.add(new Kategori(2,"Dergi","http://www.zaytung.com/mags/zaytung_dergi_tvguide_eylul2012.jpg"));
        kategoriler.add(new Kategori(3,"Felsefe","http://calakalem.com/wp-content/uploads/2017/06/felsefe-terapi.jpg"));
        kategoriler.add(new Kategori(4,"Sağlık","http://www.eczozgurozel.com/wp-content/uploads/2014/02/onkokardiyoloji_kalp_uzerindeki_etkisi.png"));
        kategoriler.add(new Kategori(5,"Matematik","https://egitimheryerde.net/wp-content/uploads/2018/05/1416163699-8568-5728-863-1.jpg"));

        adapterKategori = new AdapterKategori(kategoriler,getApplicationContext());
        gridView.setAdapter(adapterKategori);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent ıntent = new Intent(MainActivity.this, KitaplarActivity.class);
                ıntent.putExtra("kategori",kategoriler.get(position));
                startActivity(ıntent);
            }
        });

    }
}
