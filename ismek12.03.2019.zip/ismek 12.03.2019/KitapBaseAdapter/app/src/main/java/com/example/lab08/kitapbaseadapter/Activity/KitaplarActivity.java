package com.example.lab08.kitapbaseadapter.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.lab08.kitapbaseadapter.Adapter.Adapterkitap;
import com.example.lab08.kitapbaseadapter.KitapDetayActivity;
import com.example.lab08.kitapbaseadapter.Model.Kategori;
import com.example.lab08.kitapbaseadapter.Model.Kitap;
import com.example.lab08.kitapbaseadapter.R;

import java.util.ArrayList;

public class KitaplarActivity extends AppCompatActivity {
    Adapterkitap kita ;
    ArrayList<Kitap> kitaplar = new ArrayList<>();
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Kategori kategori = (Kategori) getIntent().getSerializableExtra("kategori");
        setContentView(R.layout.activity_kitaplar);
        listView = findViewById(R.id.listviewkitaplar);
       if (kategori.getId()==1)
        {
            kitaplar.add(new Kitap(
                    "Şerif güngör",
                    "Python ile programlama",
                    "Seçkin yayıncılık",
                    "Yazılım",
                    24.99,
                    210,
                    "https://www.python.org/static/opengraph-icon-200x200.png",
                    2019,
                    "Özet Yazısı"
            ));

        }
        else
       {
           if (kategori.getId()==1)
           {
               kitaplar.add(new Kitap(
                       "Şerif güngör",
                       "Python ile programlama",
                       "Seçkin yayıncılık",
                       "Yazılım",
                       24.99,
                       210,
                       "",
                       2019,
                       "Özet Yazısı"
               ));

           }
       }

        kita = new Adapterkitap(getApplicationContext(),kitaplar);
        listView.setAdapter(kita);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent ıntent = new Intent(KitaplarActivity.this,KitapDetayActivity.class);
                ıntent.putExtra("kitap",kitaplar.get(position));
                startActivity(ıntent);

            }
        });

    }
}
