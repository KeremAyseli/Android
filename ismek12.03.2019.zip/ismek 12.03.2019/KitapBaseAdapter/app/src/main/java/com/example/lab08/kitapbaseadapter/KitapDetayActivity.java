package com.example.lab08.kitapbaseadapter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toolbar;

import com.example.lab08.kitapbaseadapter.Model.Kitap;

public class KitapDetayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kitap_detay);
//        Toolbar toolbar = findViewById(R.id.toolbar);


        Kitap kitap = (Kitap) getIntent().getSerializableExtra("kitap");
        setTitle(kitap.getIsim());
    }


}
