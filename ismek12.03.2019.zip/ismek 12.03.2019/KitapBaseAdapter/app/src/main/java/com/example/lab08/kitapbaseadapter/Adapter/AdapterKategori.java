package com.example.lab08.kitapbaseadapter.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.lab08.kitapbaseadapter.Model.Kategori;
import com.example.lab08.kitapbaseadapter.R;

import java.util.ArrayList;

public class AdapterKategori extends BaseAdapter {

    private ArrayList<Kategori> kategoriler;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterKategori() {
    }

    public AdapterKategori(ArrayList<Kategori> kategoriler, Context context) {
        this.kategoriler = kategoriler;
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public ArrayList<Kategori> getKategoriler() {
        return kategoriler;
    }

    public void setKategoriler(ArrayList<Kategori> kategoriler) {
        this.kategoriler = kategoriler;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public LayoutInflater getLayoutInflater() {
        return layoutInflater;
    }

    public void setLayoutInflater(LayoutInflater layoutInflater) {
        this.layoutInflater = layoutInflater;
    }

    @Override
    public int getCount() {
        return kategoriler.size();
    }

    @Override
    public Object getItem(int position) {
        return kategoriler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = layoutInflater.inflate(R.layout.gridview_kategoriler,null);

        ImageView ivKategori = v.findViewById(R.id.ivKategori);
        TextView tvKategori = v.findViewById(R.id.tvKategori);

        tvKategori.setText(kategoriler.get(position).getIsim());

        Glide
                .with(context)
                .load(kategoriler.get(position).getResim())
                .into(ivKategori);





        return v;
    }
}
