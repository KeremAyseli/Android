package com.example.lab08.kitapbaseadapter.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.lab08.kitapbaseadapter.Model.Kitap;
import com.example.lab08.kitapbaseadapter.R;

import java.util.ArrayList;

public  class Adapterkitap extends BaseAdapter {

    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<Kitap> kitaplar;


    public Adapterkitap(Context context, ArrayList<Kitap> kitaplar) {
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        this.kitaplar = kitaplar;

    }

    public Adapterkitap() {
    }

    @Override
    public int getCount() {
        return kitaplar.size();
    }

    @Override
    public Object getItem(int position) {
        return kitaplar.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = layoutInflater.inflate(R.layout.listview_kitaplar,null);

        ImageView ivResim = v.findViewById(R.id.imageView);
        TextView tvYazar= v.findViewById(R.id.Yazar);
        TextView tvFiyat = v.findViewById(R.id.fiyat);
        TextView tvBaslik = v.findViewById(R.id.baslik);
        TextView tvsayfaSayısı = v.findViewById(R.id.sayfaSayısı);

        tvBaslik.setText(""+kitaplar.get(position).getIsim());
        tvFiyat.setText(""+kitaplar.get(position).getFiyat());
        tvsayfaSayısı.setText(""+kitaplar.get(position).getSayfaSayisi());
        tvYazar.setText(""+kitaplar.get(position).getYazar());
        Glide.with(context).load(kitaplar.get(position).getResim());

        return v;

    }
}
