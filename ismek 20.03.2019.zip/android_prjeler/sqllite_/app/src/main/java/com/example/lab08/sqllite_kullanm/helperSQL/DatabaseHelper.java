package com.example.lab08.sqllite_kullanm.helperSQL;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.lab08.sqllite_kullanm.Model.Rehber;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int VERITABANI_SURUMU = 1;
    private static final String VERITABANI_ADI = "Tablolar";
    private static final String DB_TABLO_REHBER = "Notlar5";
    private static final String TABLO_REHBER_ID = "id";
    private static final String TABLO_REHBER_AD = "ad";
    private static final String TABLO_REHBER_SOYAD = "soyad";
    private static final String TABLO_REHBER_TELEFONNO = "telefonNo";
    private static final String TABLO_REHBER_MAILADRESI = "mailAdresi";
    private static final String TABLO_REHBER_TELEFONTURU = "telefonTuru";
    private static final String TABLO_REHBER_RESIM = "resim";
    private static final String TABLO_REHBER_WEBSITE = "webSite";
    private static final String TABLO_REHBER_NOTICERIGI = "notIcerigi";

    public DatabaseHelper(Context context) {
        super(context, VERITABANI_ADI, null, VERITABANI_SURUMU);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {


  StringBuilder sb = new StringBuilder();


        sb.append("CREATE TABLE IF NOT EXISTS "+DB_TABLO_REHBER+" (");
        sb.append(TABLO_REHBER_ID+" INTEGER PRIMARY KEY AUTOINCREMENT,");
        sb.append(TABLO_REHBER_AD+" VARCHAR (75),");
        sb.append(TABLO_REHBER_SOYAD+" VARCHAR (75),");
        sb.append(TABLO_REHBER_TELEFONNO+" VARCHAR (25),");
        sb.append(TABLO_REHBER_MAILADRESI+"	VARCHAR (75),");
        sb.append(TABLO_REHBER_TELEFONTURU+" VARCHAR (75),");
        sb.append(TABLO_REHBER_RESIM+" VARCHAR,");
        sb.append(TABLO_REHBER_WEBSITE+" VARCHAR,");
        sb.append(TABLO_REHBER_NOTICERIGI+" TEXT");
        sb.append(")");
   db.execSQL(sb.toString());
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        /* Veri tabanının güncellenmesi amacı ile kullanılır yeni eklenen tablolar ,kolonlar gibi değişiklikleri güncel yazılıma adapte etmek için eski veritabanı sürümü ,yeni bir sürüm ile adapte etmek için kullanılır*/
        /*Eğer varsa tabloları sil */
        db.execSQL("DROP TABLE IF EXISTS "+DB_TABLO_REHBER);
        onCreate(db);
    }
    public void notekle(Rehber rehber){
        SQLiteDatabase db = this.getWritableDatabase();
        /*getWritableDatabase() Veritabanını yazmak amaçlı açar */
        ContentValues veri = new ContentValues();

        veri.put(TABLO_REHBER_AD,rehber.getAd());
        veri.put(TABLO_REHBER_MAILADRESI,rehber.getMailAdresi());
        veri.put(TABLO_REHBER_RESIM,rehber.getResim());
        veri.put(TABLO_REHBER_NOTICERIGI,rehber.getNot());
        veri.put(TABLO_REHBER_SOYAD,rehber.getSoyad());
        veri.put(TABLO_REHBER_TELEFONNO,rehber.getTelefonNo());
        veri.put(TABLO_REHBER_TELEFONTURU,rehber.getTelefonTuru());
        veri.put(TABLO_REHBER_WEBSITE,rehber.getWebSite());
        db.insert(DB_TABLO_REHBER,null,veri);
        db.close();

    }
    public Rehber Rehber_getRehberkisi(int id){
        SQLiteDatabase DB =this.getReadableDatabase();
        Cursor cursor = DB.rawQuery("select * from "+DB_TABLO_REHBER+"where "+TABLO_REHBER_ID+"="+id,null);
        if (cursor != null)
            cursor.moveToFirst();

        Rehber rehber = new Rehber();

        return rehber;


    }
    public List<Rehber> getTumkisiller(){
        List<Rehber>rehberlist = new ArrayList<>();
        String selectQuery = "SELECT  * FROM " + DB_TABLO_REHBER;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                Rehber rehber = new Rehber();
                rehber.setAd(c.getString(c.getColumnIndex(TABLO_REHBER_AD)));
                rehber.setId(c.getInt(c.getColumnIndex(TABLO_REHBER_ID)));
                rehber.setMailAdresi(c.getString(c.getColumnIndex(TABLO_REHBER_MAILADRESI)));
                rehber.setNot(c.getString(c.getColumnIndex(TABLO_REHBER_NOTICERIGI)));
                rehber.setSoyad(c.getColumnName(c.getColumnIndex(TABLO_REHBER_SOYAD)));
                rehber.setResim(c.getColumnName(c.getColumnIndex(TABLO_REHBER_RESIM)));
                rehber.setTelefonNo(c.getColumnName(c.getColumnIndex(TABLO_REHBER_TELEFONNO)));
                rehber.setTelefonTuru(c.getColumnName(c.getColumnIndex(TABLO_REHBER_TELEFONTURU)));
                rehber.setTelefonTuru(c.getColumnName(c.getColumnIndex(TABLO_REHBER_WEBSITE)));
                rehberlist.add(rehber);
            } while (c.moveToNext());
        }

        // return contact list
        return rehberlist;



    }
    /*Cursor sınıfı,veritabnına gönderilen select sorgusunda dönen tüm sonuçların listelenmesini ve kolon değerlerinin listelenemesi amaçlı kullanılır */
    public int kisigüncelle(Rehber rehber){
        SQLiteDatabase db =this.getWritableDatabase();

        ContentValues veri = new ContentValues();
        veri.put(TABLO_REHBER_AD,rehber.getAd());
        veri.put(TABLO_REHBER_MAILADRESI,rehber.getMailAdresi());
        veri.put(TABLO_REHBER_RESIM,rehber.getResim());
        veri.put(TABLO_REHBER_NOTICERIGI,rehber.getNot());
        veri.put(TABLO_REHBER_SOYAD,rehber.getSoyad());
        veri.put(TABLO_REHBER_TELEFONNO,rehber.getTelefonNo());
        veri.put(TABLO_REHBER_TELEFONTURU,rehber.getTelefonTuru());
        veri.put(TABLO_REHBER_WEBSITE,rehber.getWebSite());
        return db.update(DB_TABLO_REHBER,veri,TABLO_REHBER_ID+"=?",new String[]{String.valueOf(rehber.getId())});

    }
    public int getrehberKisisayısı (){
        String CountQuery = "SELECT * FROM "+DB_TABLO_REHBER;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(CountQuery,null);
        cursor.close();
        return cursor.getCount();
        /*
        Select sorgusundan dönen tüm satır sayısını döndüren metottur.
         */
    }
    public void kisiSil(Rehber kisi) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(DB_TABLO_REHBER, TABLO_REHBER_ID + " = ?",
                new String[] { String.valueOf(kisi.getId()) });
        db.close();
        /*
        Veritabanından kişi silmek için, id değerini bildiğimiz bir satırı silebiliriz.
        Argümandan rehber tipinde veri alarak kisi nesnesinin getId() metodundan kişinin
        id'sini yakalayabiliriz.
         */
    }

}
