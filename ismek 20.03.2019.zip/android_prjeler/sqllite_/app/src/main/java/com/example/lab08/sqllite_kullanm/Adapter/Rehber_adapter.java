package com.example.lab08.sqllite_kullanm.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.lab08.sqllite_kullanm.Model.Rehber;
import com.example.lab08.sqllite_kullanm.R;

import java.util.ArrayList;

public class Rehber_adapter extends BaseAdapter {
   ArrayList<Rehber> rehber ;
   Context context;
   LayoutInflater layoutInflater;

    public Rehber_adapter() {
    }

    public Rehber_adapter(ArrayList<Rehber> rehber, Context context) {
        this.rehber = rehber;
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return rehber.size();
    }

    @Override
    public Object getItem(int position) {
        return rehber.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v =layoutInflater.inflate(R.layout.kisi_satirgoruntusu,null);
        TextView tvAd,tvSoyad,tvTelefon,tvTelefonTur;
        ImageView ivResim;
        tvAd = v.findViewById(R.id.tvİsim);
        tvSoyad = v.findViewById(R.id.tvSoyad);
        tvTelefon = v.findViewById(R.id.tvTelefonNumara);
        tvTelefonTur = v.findViewById(R.id.tvTelefonTur);
        ivResim = v.findViewById(R.id.ivResim);
        Glide.with(context).load(rehber.get(position).getResim()).into(ivResim);
        tvAd.setText(rehber.get(position).getAd());
        tvSoyad.setText(rehber.get(position).getSoyad());
        tvTelefon.setText(rehber.get(position).getTelefonNo());
        tvTelefonTur.setText(rehber.get(position).getTelefonTuru());


        return v;
    }
}
