package com.example.lab08.ntent_1;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {
EditText etnumara,etsite;
Button btnwb,btnara;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etnumara = findViewById(R.id.etTelefonNumarasi);
        etsite = findViewById(R.id.etWebsite);
        btnwb = findViewById(R.id.btnWeb);
        btnara = findViewById(R.id.btnAra);
        btnara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ıntent = new Intent(Intent.ACTION_VIEW);
                Uri uri = Uri.parse("tel:+9"+etnumara.getText().toString());
                startActivity(ıntent);
            }
        });
        btnwb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ıntent = new Intent(Intent.ACTION_VIEW);
                Uri uri = Uri.parse("http://"+etsite.getText().toString());
                ıntent.setData(uri);
                startActivity(ıntent);
            }
        });
    }
}
