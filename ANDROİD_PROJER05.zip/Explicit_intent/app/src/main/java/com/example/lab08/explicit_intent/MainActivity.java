package com.example.lab08.explicit_intent;

import android.content.ComponentName;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /* Paket adı ve Activity sayfasının ismini bildiğimiz bir uygulamayı doğrudan açabiliriz*/
        try
        {
            Intent ıntent = new Intent();
            String paketAdi = "com.example.lab08.implicit_intent";
            String sınıfadi = paketAdi+".MainActivity";
            ıntent.setComponent(new ComponentName(paketAdi,sınıfadi));
            startActivity(ıntent);

        }
        catch (Exception e)

        {
            Toast.makeText(getApplicationContext(),"Telefonunuzda istedğiniz uygulama mevcut değil",Toast.LENGTH_LONG);
        }
    }
}
