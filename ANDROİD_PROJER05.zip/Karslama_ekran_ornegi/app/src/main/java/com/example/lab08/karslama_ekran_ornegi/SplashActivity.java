package com.example.lab08.karslama_ekran_ornegi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        new Acilis().start();
    }
    private class Acilis extends Thread{
        @Override
        public void  run(){
            super.run();
            try {

Thread.sleep(5000);
            }
            catch (Exception e)
            {

            }
            Intent ıntent = new Intent(SplashActivity.this,MainActivity.class);
            startActivity(ıntent);
            finish();
        }
    }
}
