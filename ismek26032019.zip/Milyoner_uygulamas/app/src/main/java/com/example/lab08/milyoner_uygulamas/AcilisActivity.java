package com.example.lab08.milyoner_uygulamas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class AcilisActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acilis);
        this.getSupportActionBar().hide();
        new Beklet().start();
    }
    private class Beklet extends Thread{
        @Override
        public void run() {
            super.run();
            try {
                Thread.sleep(3000);
            }catch (Exception e)
            {
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
            }
        }
    }
}
