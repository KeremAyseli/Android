package com.example.lab08.intent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
 TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
   textView = findViewById(R.id.textView);
         String meyve_ismi=getIntent().getStringExtra("Portakal");
        String meyve_ismi1=getIntent().getStringExtra("elma");
        String meyve_ismi2=getIntent().getStringExtra("çilek");
        String meyve_ismi3=getIntent().getStringExtra("kiraz");
        textView.setText(meyve_ismi+""+meyve_ismi1+""+meyve_ismi2+""+meyve_ismi3);
    }
}
