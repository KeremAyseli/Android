package com.example.lab08.intentmeyve;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        textView=findViewById(R.id.textView);
        String ad =getIntent().getStringExtra("ad");
        String soyad =getIntent().getStringExtra("soyad");
        int yas=getIntent().getIntExtra("yas",0);
        textView.setText(ad+""+soyad+""+yas);
    }
}
