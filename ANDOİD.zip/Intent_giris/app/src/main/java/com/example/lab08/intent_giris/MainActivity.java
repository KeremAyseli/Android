package com.example.lab08.intent_giris;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText etPosta,etSifre;
    Button btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etPosta=findViewById(R.id.editPosta);
        etSifre=findViewById(R.id.edSifre);
        btn=findViewById(R.id.btngiris);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if("admin@gmail.com".equals(etPosta.getText().toString())&&"1234".equals(etSifre.getText().toString()))
                {final Intent Intent = new Intent(MainActivity.this,SecondActivitY.class);
                    Intent.putExtra("eposta",etPosta.getText().toString());
                    startActivity(Intent);
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"E-posta veya şifreniz hatalı",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
