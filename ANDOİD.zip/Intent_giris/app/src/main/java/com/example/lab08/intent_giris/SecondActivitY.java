package com.example.lab08.intent_giris;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivitY extends AppCompatActivity {
 TextView edtxt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_activit_y);
        String edt =getIntent().getStringExtra("eposta").toString();
        edtxt.setText(edt+"Hoşgeldiniz");
    }
}
