package com.example.lab08.intent_hesapmakinesi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ViewDebug;
import android.widget.TextView;

public class seconfActivity extends AppCompatActivity {
    TextView tip1,sonuc;
    TextView tip2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seconf);
        int degerler=getIntent().getIntExtra("hesaplama",0);
        String tip = getIntent().getStringExtra("veritipi");
        sonuc.setText(""+degerler+"");
        tip1.setText(tip);
    }
}
