package com.example.lab08.intent_hesapmakinesi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Button btntopla,btncıkar,btnböl,btncarp;
    EditText sayı1,sayı2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btntopla = findViewById(R.id.btnTopla);
        btncıkar = findViewById(R.id.btncıkar);
        btnböl = findViewById(R.id.btnBöl);
        btncarp = findViewById(R.id.btnCarp);
        sayı1 = findViewById(R.id.etsayı1);
        sayı2 =findViewById(R.id.etsayı2);


       btnböl.setOnClickListener(this);
       btntopla.setOnClickListener(this);
       btncıkar.setOnClickListener(this);
       btncarp.setOnClickListener(this);



    }

    @Override
    public void onClick(View v) {
        Intent ıntern =new Intent(MainActivity.this,seconfActivity.class);
        if(v.getId()==R.id.btnBöl)
        {
            ıntern.putExtra("hesaplama",Integer.parseInt(sayı1.getText().toString())/Integer.parseInt(sayı2.getText().toString()));
            ıntern.putExtra("veritipi","böl");

        }
        else if (v.getId()==R.id.btnTopla){
            ıntern.putExtra("hesaplama",Integer.parseInt(sayı1.getText().toString())+Integer.parseInt(sayı2.getText().toString()));
            ıntern.putExtra("veritipi","topla");
        }
        else if (v.getId()==R.id.btnCarp)
        {
            ıntern.putExtra("hesaplama",Integer.parseInt(sayı1.getText().toString())*Integer.parseInt(sayı2.getText().toString()));
            ıntern.putExtra("veritipi","carp");
        }
        else if(v.getId()==R.id.btncıkar)
        {
            ıntern.putExtra("hesaplama",Integer.parseInt(sayı1.getText().toString())-Integer.parseInt(sayı2.getText().toString()));
            ıntern.putExtra("veritipi","cıkar");
        }
            startActivity(ıntern);
    }
}
