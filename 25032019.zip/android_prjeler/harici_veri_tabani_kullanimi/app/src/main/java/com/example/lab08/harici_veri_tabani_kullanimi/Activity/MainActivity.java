package com.example.lab08.harici_veri_tabani_kullanimi.Activity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.example.lab08.harici_veri_tabani_kullanimi.Helper.Database_Helper;
import com.example.lab08.harici_veri_tabani_kullanimi.R;

public class MainActivity extends AppCompatActivity {
    Database_Helper databaseHelper;
    SQLiteDatabase db;
    Cursor c;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        try{
            databaseHelper = new Database_Helper(getApplicationContext());
            databaseHelper.createDatabase();
            db = databaseHelper.getReadableDatabase();
            c = db.rawQuery("Select * from Ogrenciler order by id desc",null);
            while(c.moveToNext()){
                Log.i("DB_LOG",c.getInt(0)+" "+c.getString(1));
            }

        }catch(Exception e){
            Log.e("DB_LOG",e.getMessage());
            Log.e("DB_LOG","Veritabanı oluşturulamadı veya kopyalanamadı !");
        }
    }
}
