package com.example.lab08.sqllite_kullanm.Activity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.lab08.sqllite_kullanm.Adapter.Rehber_adapter;
import com.example.lab08.sqllite_kullanm.Model.Rehber;
import com.example.lab08.sqllite_kullanm.R;
import com.example.lab08.sqllite_kullanm.helperSQL.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
   EditText editText;
   ListView listView;
   Button button;
   Rehber_adapter rehber_adapter;
   ArrayList<Rehber>kisiler = new ArrayList<>();
   public void verileriGüncelle(){
       kisiler = (ArrayList<Rehber>)databaseHelper.getTumkisiller();
       rehber_adapter = new Rehber_adapter(kisiler,getApplicationContext());
       listView.setAdapter(rehber_adapter);
       rehber_adapter.notifyDataSetChanged();
   }

   DatabaseHelper databaseHelper;
   private void kisiGuncellemeDialog(final Rehber kisi,final String islem){

       final Dialog dialog = new Dialog(MainActivity.this);
       dialog.setContentView(R.layout.rehber_kisi_guncelle);

       final EditText etAd,etSoyad,etMail,etNot,etTelefon,etTelefonTur,etWeb;
       Button btnIslem;

       etAd = dialog.findViewById(R.id.etRehberAd);
       etSoyad = dialog.findViewById(R.id.etRehberSoyad);
       etMail = dialog.findViewById(R.id.etRehberMailAdresi);
       etNot = dialog.findViewById(R.id.etRehberNot);
       etTelefon = dialog.findViewById(R.id.etRehberTelefon);
       etTelefonTur = dialog.findViewById(R.id.etRehberTelefonTur);
       etWeb = dialog.findViewById(R.id.etRehberWebSite);
       btnIslem = dialog.findViewById(R.id.btnRehberIslem);
       if(btnIslem.equals("güncelle")) {
       etAd.setText(kisi.getAd());
       etSoyad.setText(kisi.getSoyad());
       etMail.setText(kisi.getMailAdresi());
       etNot.setText(kisi.getNot());
       etTelefon.setText(""+kisi.getTelefonNo());
       etTelefonTur.setText(kisi.getTelefonTuru());
       etWeb.setText(kisi.getWebSite());

 btnIslem.setText("Güncelle");
       btnIslem.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

               kisi.setWebSite(etWeb.getText().toString());
               kisi.setTelefonTuru(etTelefonTur.getText().toString());
               kisi.setTelefonNo(etTelefon.getText().toString());
               kisi.setNot(etNot.getText().toString());
               kisi.setMailAdresi(etMail.getText().toString());
               kisi.setAd(etAd.getText().toString());
               kisi.setSoyad(etSoyad.getText().toString());
               databaseHelper.kisigüncelle(kisi);
                //Dialog nesnesini kapatır
               dialog.dismiss();

           }
       });}

       else if(islem.equals("ekle")){
              btnIslem.setText("Ekle");
              btnIslem.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View v) {
                      Rehber rehber = new Rehber();
                      rehber.setAd(etAd.getText().toString());
                      rehber.setMailAdresi(etMail.getText().toString());
                      rehber.setResim("");
                      rehber.setNot(etNot.getText().toString());
                      rehber.setSoyad(etSoyad.getText().toString());
                      rehber.setTelefonNo(etTelefon.getText().toString());
                      rehber.setTelefonTuru(etTelefonTur.getText().toString());
                      rehber.setWebSite(etWeb.getText().toString());
                      databaseHelper.notekle(rehber);
                      dialog.dismiss();
                      verileriGüncelle();
                  }
              });
       }

       else if(islem.equals("sil")){
           btnIslem.setText("Sil");
           btnIslem.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   Rehber rehber = new Rehber();
                   rehber.setAd(etAd.getText().toString());
                   rehber.setSoyad(etSoyad.getText().toString());
                   rehber.setMailAdresi(etMail.getText().toString());
                   rehber.setNot(etNot.getText().toString());
                   rehber.setTelefonNo(etTelefon.getText().toString());
                   rehber.setTelefonTuru(etTelefonTur.getText().toString());
                   rehber.setResim("");
                   rehber.setWebSite(etWeb.getText().toString());
                   databaseHelper.kisiSil(kisi);
                   //dialog.dismiss();
               }
           });
       }


       dialog.show();
   }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText=findViewById(R.id.etArama);
        listView =findViewById(R.id.listViewKisiler);
        button = findViewById(R.id.btnKisiEkle);
        databaseHelper = new DatabaseHelper(getApplicationContext());
        kisiler = (ArrayList<Rehber>) databaseHelper.getTumkisiller();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                kisiGuncellemeDialog(
                        null,"ekle"
                );
            }
        });

        rehber_adapter=new Rehber_adapter(kisiler,getApplicationContext());
        listView.setAdapter(rehber_adapter);
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
                adb.setTitle("işlem seçiniz");
                adb.setMessage("Silmek ya da güncellemek üzere bir butona tıklayanız");
                adb.setPositiveButton("Güncelle", new DialogInterface.OnClickListener() {
                    @Override //int id,String ad,String soyad, String email,String not,String telefon,String telefonTur,String webSite
                    public void onClick(DialogInterface dialog, int which) {
                        kisiGuncellemeDialog(kisiler.get(position),"güncelle");
                    }
                });
                adb.setNegativeButton("Sil", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                           databaseHelper.kisiSil(kisiler.get(position));
                    }
                });
                adb.setNeutralButton("Vazgeç", null);
                adb.create();
                adb.show();
                return false;
            }
        });

    }
}
